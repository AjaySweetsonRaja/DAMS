<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>


<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        text-align: center;
    }
</style>
</head>

<body>



<div style="display:flex;margin:0;padding:0;width:1000px;margin:0 auto;height:200px;">
<img src="images/logo.png"   style="width:200px;height:200px;" />
<div>
<p style="text-align:center;line-height:0;">DEANERY OF PROJECTS</p>
<p style="text-align:center;line-height:0;">BISHOP HEBER COLLEGE (AUTONOMOUS)</p>
<p style="text-align:center;line-height:0;font-family:cursive;">Ranked 39 th at National Level by MHRD through NIRF 2019</p>
<p style="text-align:center;line-height:0;font-family:cursive;">(Nationally Reaccredited at the A Grade by NAAC with the CGPA of 3.69 out of 4)</p>

<p style="text-align:center;line-height:0;font-family:cursive;">Recognized by UGC as College of Excellence</p>
<p style="text-align:center;line-height:0;">Tiruchirappalli, Tamil Nadu</p>



</div>


</div>
<hr />




                    <div>
					<h2 style="text-align:center">DEPARTMENT ACCOUNTS AUDIT TEMPLATE</h2>
					
					
					<div style="display:flex;justify-content:space-around;">
					<h4>Name Of The Department:<input type="text" style="border-bottom:1px solid black;;" /></h4>  <h4>For the period::<h2>(1 June 2022 to 31 May 2023)</h2></h4>
					</div>
					
					
					<h2 style="text-align:center">DEPARTMENT RECEIPTS AND PAYMENTS STATEMENT</h2>
					
					
					<h3 style="text-align:center">A. DEPARTMENT INCOME</h3>
					
					
					<p>I. Money collected from Students</p>
					
					<table>
    <thead>
        <tr>
            <th>S. No</th>
            <th>Heading</th>
            <th>UG / PG</th>
            <th>Amount per Student</th>
            <th>Total no. of Students</th>
            <th>Total Amount collected

Rs.</th>
          
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>Association Fee collected</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
           
        </tr>
        <tr>
            <td>2</td>
            <td>Book money collected</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
          
        </tr>
        <tr>
            <td>3</td>
            <td>Record money collected</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
          
        </tr>
        <tr>
            <td>4</td>
            <td>Money collected for Lab Coat / Blazer etc.,</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
         
        </tr>
        <tr>
            <td>5</td>
            <td>Money collected for certificate / Diploma course</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
         
        </tr>
        <tr>
            <td>6</td>
            <td>Industrial Visit Money Collected</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
           
        </tr>
		  <tr>
            <td>7</td>
            <td>Money collected for any other purpose (Specify)</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
           
      
    </tbody>
</table>

				<div style="width:300px;margin:50px auto;"> 
			
			<input type="submit" name="btn2" style="padding:10px 20px;background:#006600;border-radius:5px;color:#FFFFFF;font-weight:700;" />
			<input type="reset" style="padding:10px 20px;background:red;border-radius:5px;color:#FFFFFF;font-weight:700;" value="Reset" />
			
			
			
			</div>	
					
					
					</div>




</body>
</html>
