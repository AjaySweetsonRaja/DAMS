<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>



<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        text-align: center;
    }
</style>


</head>

<body>

                    
<div style="display:flex;margin:0;padding:0;width:1000px;margin:0 auto;height:200px;">
<img src="images/logo.png"   style="width:200px;height:200px;" />
<div>
<p style="text-align:center;line-height:0;">DEANERY OF PROJECTS</p>
<p style="text-align:center;line-height:0;">BISHOP HEBER COLLEGE (AUTONOMOUS)</p>
<p style="text-align:center;line-height:0;font-family:cursive;">Ranked 39 th at National Level by MHRD through NIRF 2019</p>
<p style="text-align:center;line-height:0;font-family:cursive;">(Nationally Reaccredited at the A Grade by NAAC with the CGPA of 3.69 out of 4)</p>

<p style="text-align:center;line-height:0;font-family:cursive;">Recognized by UGC as College of Excellence</p>
<p style="text-align:center;line-height:0;">Tiruchirappalli, Tamil Nadu</p>



</div>


</div>
<hr />












                        <div>
						
						
						
						
							<h2 style="text-align:center">RECEIPTS AND PAYMENTS For the period:: (1 June 2022 to 31 May 2023)</h2>
						
						
						
						
						
						
						<table>
    <thead>
        <tr>
            <th>S. No</th>
            <th>Particulars</th>
            <th>Receipts Rs.</th>
            <th>Payments Rs.</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>I</td>
            <td style="text-align:left;font-weight:800;">Opening Balance Amount</td>
            <td colspan="2"><input type="text" /></td>
            
        </tr>
        <tr>
            <td>II</td>
            <td colspan="3" style="text-align:left;font-weight:800;">Income</td>
   
        </tr>
        <tr>
            <td>1</td>
            <td style="text-align:left">Money collected from Students</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            <td>2</td>
            <td style="text-align:left">Money collected from Participants for organizing Conference / workshop/ Skill development / Seminar etc</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            <td>3</td>
            <td style="text-align:left">Money received from Management</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            <td>4</td>
            <td style="text-align:left">Money received from Alumni</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            <td>5</td>
            <td style="text-align:left">Fixed deposit money</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            <td>6</td>
            <td style="text-align:left">Any other (Specify)</td>
            <td><input type="text" /></td>
            <td><input type="text" /></td>
        </tr>
        <tr>
            
            <td colspan="2" style="text-align:right;font-weight:800;">TOTAL</td>
            <td><input type="text" /></td>
			<td><input type="text" /></td>
        </tr>
       <tr>
            
            <td colspan="2" style="text-align:right;font-weight:800;">BALANCE</td>
            <td><input type="text" /></td>
			<td><input type="text" /></td>
        </tr>
       
    </tbody>
</table>
						
						
						<div style="width:300px;margin:50px auto;"> 
			
			<input type="submit" name="btn2" style="padding:10px 20px;background:#006600;border-radius:5px;color:#FFFFFF;font-weight:700;" />
			<input type="reset" style="padding:10px 20px;background:red;border-radius:5px;color:#FFFFFF;font-weight:700;" value="Reset" />
			
			
			
			</div>	
						
						
						
						
						
						
						
						
						</div>

                 
</body>
</html>
